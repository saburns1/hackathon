export function v4(): string;
