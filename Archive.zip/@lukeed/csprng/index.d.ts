export function random<T = Buffer | Uint8Array>(len: number): T;
