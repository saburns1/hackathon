export function random<T=Uint8Array>(len: number): T;
