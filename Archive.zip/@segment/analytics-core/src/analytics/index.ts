export interface CoreAnalytics {
  track(...args: unknown[]): unknown
  page(...args: unknown[]): unknown
  identify(...args: unknown[]): unknown
  group(...args: unknown[]): unknown
  alias(...args: unknown[]): unknown
  screen(...args: unknown[]): unknown
  register(...plugins: unknown[]): Promise<unknown>
  deregister(...plugins: unknown[]): Promise<unknown>
  readonly VERSION: string
}
