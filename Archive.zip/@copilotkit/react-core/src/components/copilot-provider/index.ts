export { CopilotKit, defaultCopilotContextCategories } from "./copilotkit";

export type { CopilotKitProps } from "./copilotkit-props";
