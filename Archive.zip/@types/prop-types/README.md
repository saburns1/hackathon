# Installation
> `npm install --save @types/prop-types`

# Summary
This package contains type definitions for prop-types (https://github.com/facebook/prop-types).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/prop-types.

### Additional Details
 * Last updated: Thu, 05 Dec 2024 19:32:25 GMT
 * Dependencies: none

# Credits
These definitions were written by [DovydasNavickas](https://github.com/DovydasNavickas), [Ferdy Budhidharma](https://github.com/ferdaber), and [Sebastian Silbermann](https://github.com/eps1lon).
