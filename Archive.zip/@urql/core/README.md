# @urql/core

> The shared core for the highly customizable and versatile GraphQL client, urql

More documentation is available at [formidable.com/open-source/urql](https://formidable.com/open-source/urql/).
