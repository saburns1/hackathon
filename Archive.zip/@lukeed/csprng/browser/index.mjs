export function random(len) {
	return crypto.getRandomValues(new Uint8Array(len));
}
