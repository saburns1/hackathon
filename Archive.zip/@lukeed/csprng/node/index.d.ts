export function random<T=Buffer>(len: number): T;
